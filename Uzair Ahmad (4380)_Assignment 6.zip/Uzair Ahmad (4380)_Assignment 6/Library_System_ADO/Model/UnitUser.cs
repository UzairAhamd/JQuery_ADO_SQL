﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Library_System_ADO.Model
{
    public class UnitUser
    {
        public int UserID { get; set; }
        public string Username { get; set; }
    }
}
