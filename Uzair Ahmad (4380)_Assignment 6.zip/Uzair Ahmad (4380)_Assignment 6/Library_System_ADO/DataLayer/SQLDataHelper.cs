﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Library_System_ADO.BusinessLayer;
using Microsoft.Extensions.Configuration;
using Library_System_ADO.Model;

namespace Library_System_ADO.DataLayer
{
    public class SQLDataHelper : ISQLDataHelper
    {
        //String Configuration 
        private readonly IConfiguration _configuration;
        string connectionString = "";
        public SQLDataHelper(IConfiguration config)
        {
            _configuration = config;
            connectionString = _configuration.GetConnectionString("ProjectDB");
        }
        //Task0 fetch all books to deliver to BAL
        public List<UnitBook> GetBooksData()
        {
            List<UnitBook> lstBook = new List<UnitBook>();  //list of UnitBook objects to store books
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                string query = "sp_GetBooks";  //querying for GetBooks stored procedure
                SqlDataAdapter SDA = new SqlDataAdapter(query, con);    //creating and setting adapater using query and connection
                SDA.SelectCommand.CommandType = CommandType.StoredProcedure; //Setting comand type as stored Procedure
                con.Open(); //open the connection to database
                SDA.SelectCommand.ExecuteNonQuery();    //execute recently set sp 
                DataTable dt = new DataTable();     //create new datatable to store db table
                SDA.Fill(dt);   //fill the datatable by data coming from db
                //iterate through the datatable to put every book to the list of books' objects 
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    UnitBook Book_Obj = new UnitBook(); //create a new UnitBook object
                    Book_Obj.BookID = Convert.ToInt32(dt.Rows[i]["BookID"]);    //get,store BookID
                    Book_Obj.BookName = dt.Rows[i]["Bookname"].ToString();      //get,store BookName
                    Book_Obj.Category = dt.Rows[i]["Category"].ToString();      //get,store Category
                    Book_Obj.Price = Convert.ToDouble(dt.Rows[i]["Price"].ToString());  //get,store Price
                    Book_Obj.ShelfNumber = Convert.ToInt32(dt.Rows[i]["ShelfNumber"]);  //get,store ShelfNumber
                    Book_Obj.IssuedStatus = dt.Rows[i]["IssuedStatus"].ToString(); //get,store ShelfNumber
                    
                    //check if the issued To is null in case deal with it
                    if (dt.Rows[i]["IssuedTo"] != DBNull.Value)
                    {
                        Book_Obj.IssuedTo = Convert.ToInt32(dt.Rows[i]["IssuedTo"]);  //get,store Issued To
                    }
                    //check if the issued date is null in case deal with it
                    if (dt.Rows[i]["IssuedDate"] != DBNull.Value)
                    {
                        Book_Obj.IssuedDate = Convert.ToDateTime(dt.Rows[i]["IssuedDate"]); //get,store Issued Date
                    }
                    lstBook.Add(Book_Obj);  //add Book_Obj in books' list
                }
                con.Close();    //close the connection to db
            }
            return lstBook; //return the list of books
        }
        // Task0 get all users and return to BAL
        public List<UnitUser> GetUsersData()
        {
            List<UnitUser> lstUser = new List<UnitUser>();  //list of UnitUser objects to store users
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                string query = "sp_GetUsers";  //querying for GetUsers stored procedure
                SqlDataAdapter SDA = new SqlDataAdapter(query, con);    //creating and setting adapater using query and connection
                SDA.SelectCommand.CommandType = CommandType.StoredProcedure; //Setting comand type as stored Procedure
                con.Open(); //open the connection to database
                SDA.SelectCommand.ExecuteNonQuery();    //execute recently set sp 
                DataTable dt = new DataTable();     //create new datatable to store db table
                SDA.Fill(dt);   //fill the datatable by data coming from db
                //iterate through the datatable to put every user to the list of usres' objects 
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    UnitUser User_Obj = new UnitUser(); //create a new UnitUser object
                    User_Obj.UserID = Convert.ToInt32(dt.Rows[i]["UserID"]);    //get,store UserID
                    User_Obj.Username = dt.Rows[i]["Username"].ToString();      //get,store Username
                    lstUser.Add(User_Obj);
                }
                con.Close();    //close the connection to db
            }
            return lstUser; //return the list of users
        }        
        // Task1 Add a new book to the books table in db
        public string AddBookData(UnitBook unitBook)
        {
            using (SqlConnection con = new SqlConnection(connectionString))//connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_InsertBook", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@Bookname", unitBook.BookName);//set BookName parameter
                cmd.Parameters.AddWithValue("@Category", unitBook.Category);//set Category parameter
                cmd.Parameters.AddWithValue("@Price", unitBook.Price);  //set Price parameter
                cmd.Parameters.AddWithValue("@ShelfNumber", unitBook.ShelfNumber);  //set ShelfNumber parameter
                cmd.Parameters.AddWithValue("@IssuedStatus", unitBook.IssuedStatus);  //set ShelfNumber parameter
                cmd.ExecuteNonQuery();//execute the stored procedure
                con.Close();//close the connection to db
            }//BookID bears idetity in db
            return "book added";    //show msg 
        }
        //Task2 add a new user to user's list in db
        public string AddUserData(UnitUser unitUser)
        {
            using (SqlConnection con = new SqlConnection(connectionString))//connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_InsertUser", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@Username", unitUser.Username);//set Usrename parameter
                cmd.ExecuteNonQuery();//execute the stored procedure
                con.Close();//close the connection to db
            }//BookID bears idetity in db
            return "user added";    //show msg if success
        }
        //Task3 get a book's details
        public UnitBook GetBookData(string bookname)
        {
            UnitBook Book_Obj = new UnitBook(); //create a new UnitBook object
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_GetBook", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@Bookname", bookname);//set BookName parameter
                cmd.ExecuteNonQuery();//execute the stored procedure
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read through each column of a row
                while (sdr.Read())
                {
                    Book_Obj.BookID= Convert.ToInt32(sdr["BookID"]);    //get and set book id
                    Book_Obj.BookName = sdr["BookName"].ToString(); //get and set book name
                    Book_Obj.Category = sdr["Category"].ToString(); //get and set category
                    Book_Obj.Price = (double)Convert.ToDecimal(sdr["Price"].ToString()); //get and set price
                    Book_Obj.ShelfNumber = Convert.ToInt32(sdr["ShelfNumber"].ToString());//get and set shelf number
                    Book_Obj.IssuedStatus = sdr["IssuedStatus"].ToString(); //get and set issued status
                    //check if the issued To is null in case deal with it
                    if (sdr["IssuedTo"] != DBNull.Value)
                    {
                        Book_Obj.IssuedTo = Convert.ToInt32(sdr["IssuedTo"]);  //get,store Issued To
                    }
                    //check if the issued date is null in case deal with it
                    if (sdr["IssuedDate"] != DBNull.Value)
                    {
                        Book_Obj.IssuedDate = Convert.ToDateTime(sdr["IssuedDate"]); //get,store Issued Date
                    }
                }
                con.Close();//close the connection to db
            }//BookID bears idetity in db
            if(Book_Obj.BookID ==0)
            { Book_Obj.BookName = bookname; }
            return Book_Obj; //return the list of books
        }
        //Task4 Get a users data including the issued books
        public Tuple<int, string, List<string>> GetUserData(int userID)
        {
            int userId = 0;
            string userName = "";
            string bookName = "No Books";
            List<string> lstUserBooks = new List<string>();  //list of UnitUser objects to store users
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_GetUser", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@UserID", userID);//set UserID parameter
                cmd.ExecuteNonQuery();//execute the stored procedure
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the data of the user
                while (sdr.Read())
                {
                    userId = Convert.ToInt32(sdr["UserID"]);    //get,set UserID
                    userName = sdr["Username"].ToString();      //get,set Username
                    //check if the books are null in case deal with it
                    if (sdr["Bookname"] != DBNull.Value)
                    {
                        bookName = sdr["Bookname"].ToString(); //get,store Issued Date
                    }
                    lstUserBooks.Add(bookName);  //add Book_Obj in books' list
                }
                con.Close();//close the connection to db
            }
            if(userId ==0)
            { return new Tuple<int, string, List<string>>(userID, "No User", lstUserBooks); }
            return new Tuple<int, string, List<string>> (userId, userName,lstUserBooks); //return the list of books along with user id and name
        }
        //Task5 udpate a book details
        public string UpdateBookData(int BookID, UnitBook unitBOOK)
        {
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_UpdateBook", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@BookID", BookID);//set BookName parameter
                cmd.Parameters.AddWithValue("@Bookname", unitBOOK.BookName);//set BookName parameter
                cmd.Parameters.AddWithValue("@Category", unitBOOK.Category);//set Category parameter
                cmd.Parameters.AddWithValue("@Price", unitBOOK.Price);  //set Price parameter
                cmd.Parameters.AddWithValue("@ShelfNumber", unitBOOK.ShelfNumber);  //set ShelfNumber parameter
                cmd.Parameters.AddWithValue("@IssuedStatus", unitBOOK.IssuedStatus);  //set ShelfNumber parameter
                cmd.ExecuteNonQuery();//execute the stored procedure
                con.Close();//close the connection to db
            }
            return "Book Updated";
        }
        //Task6 update a user data
        public string UpdateUserData(int UserID, UnitUser unitUSER)
        {
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_UpdateUser", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@UserID", UserID);//set UserID parameter
                cmd.Parameters.AddWithValue("@Username", unitUSER.Username);//set Username parameter
                cmd.ExecuteNonQuery();//execute the stored procedure
                con.Close();//close the connection to db
            }
            return "User Updated";
        }
        //Task7 issue a book to user
        public string IssueBookData(int UserID, string bookname)
        {
            int IssuedToOutput = 0;
            string outString = "";
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_IssueBook", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@UserID", UserID);//set UserID parameter
                cmd.Parameters.AddWithValue("@Bookname", bookname);//set BookName parameter
                cmd.ExecuteNonQuery();  //execute the query 
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the data of the user
                while (sdr.Read())
                {
                    IssuedToOutput = Convert.ToInt32(sdr["Issued"]);    //get,set UserID
                }
                con.Close();//close the connection to db
            }
            if (IssuedToOutput == -1) { outString = "No User with id '" + UserID + "' exist"; }
            else if (IssuedToOutput == -2) { outString = "No Book with name '" + bookname + "' exist"; }
            else if (IssuedToOutput == -3) { outString = "'" + bookname + "' is already issued"; }
            else { outString = bookname + " has been successfully issued to User with ID: " + UserID; }
            return outString;
        }
        //Task8 remove a book form database
        public string RemoveBookData(string bookname)
        {
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_RemoveBook", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@Bookname", bookname);//set BookName parameter
                cmd.ExecuteNonQuery();  //execute the query
                con.Close();    //close the connection
            }
            return "Action performed";
        }
        //Task9 remove a user data
        public string RemoveUserData(int uderID)
        {
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_RemoveUser", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@UserID", uderID);//set UserID parameter
                cmd.ExecuteNonQuery();  //execute query
                con.Close();    //close the connection
            }
            return "Action performed";
        }
        //Task10 get all books issued by a user
        public string GetUserBooksData(int userID,string bookname)
        {
            int IssuedToOutput = 0;
            string outString = "";
            List<string> lstUserBooks = new List<string>();  //list of UnitUser objects to store users
            using (SqlConnection con = new SqlConnection(connectionString)) //connect to database using defined string 
            {
                SqlCommand cmd = new SqlCommand("sp_ReturnBook", con);//set new command with stored procedure and conection string
                cmd.CommandType = CommandType.StoredProcedure;  //set the command type as stored procedure
                con.Open();     //establish connection to db
                cmd.Parameters.AddWithValue("@UserID", userID);//set UserID parameter
                cmd.Parameters.AddWithValue("@BookName", bookname);//set UserID parameter
                cmd.ExecuteNonQuery();//execute the stored procedure
                SqlDataReader sdr = cmd.ExecuteReader();
                //read through the data
                while (sdr.Read())
                {
                    IssuedToOutput = Convert.ToInt32(sdr["Returned"]);    //get,set UserID
                }
                con.Close();//close the connection to db
            }
            if (IssuedToOutput == -1) { outString = "No User with id '" + userID + "' exist"; }
            else if (IssuedToOutput == -2) { outString = "No Book with name '" + bookname + "' exist"; }
            else if (IssuedToOutput == -3) { outString = "'" + bookname + "' is already returned"; }
            else { outString = bookname + " has been successfully returned from User with ID: " + userID; }
            return outString;
        }
    }
}
