﻿using System;
using Library_System_ADO.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Library_System_ADO.BusinessLayer
{
    public interface ILibraryCalculator
    {
        public List<UnitBook> GetBooksData();   //get books
        public string InsertBooksData(UnitBook addNewBook); //insert book
        public List<UnitUser> GetUsersData();   //get books
        public string InsertUsersData(UnitUser insertUserData);
        public UnitBook GetBook(string bookname);   //get book
        public Tuple<int, string, List<string>> GetUser(int userID); //get user
        public string UpdateBook(int BookID, UnitBook unitBOOK); //update book
        public string UpdateUser(int UserID, UnitUser unitUSER); //update user
        public string IssueBook(int UserID, string bookname);   //issue book
        public string RemoveBook(string bookname);  //remove book
        public string RemoveUser(int userID);   //remove user
        public string GetUserBooks(int userID, string bookname);   //get user issued books
        public string CalculateBookPenalty(string bookName); //calculate penalty on book rerurn
    }
}
