
$(document).ready(function () {
  $("#booksDetailsID").hide();
  $("#usersDetailsID").hide();
  $("#userDetailsID").hide();
  $("#IssueBookDetails").hide();
  $("#returnBookDetails").hide();
  // call for books on page load
  $("#allBooks").click(function () {
    $("#booksDetailsID").toggle();
    $("#usersDetailsID").hide();
    $("#userDetailsID").hide();
    $.ajax({
      url: "https://localhost:5001/penalty/books",
      method: "get",
      dataType: "json",
      contentType: "application/json",
      async: true,
      success: function (data) {
        console.log(data)
        populateBooksTable(data)
      },
      error: function (data) {
        alert('error');
      }
    });
  });
  // call for users on page load
  $("#allUsers").click(function () {
    $("#usersDetailsID").toggle();
    $("#booksDetailsID").hide();
    $("#userDetailsID").hide();

    $.ajax({
      url: "https://localhost:5001/penalty/users",
      method: "get",
      dataType: "json",
      contentType: "application/json",
      async: true,
      success: function (data) {
        console.log(data)
        populateUsersTable(data)
      },
      error: function (data) {
        alert('error');
      }
    });
  });
  // Add book detail Section popup 
  $("#addBook").click(function () {
    $("#addBookDetail").toggle();
    $("#addUserDetail").hide();
    $("#getBookDetail").hide();
    $("#getUserDetail").hide();
    $("#CalPenaltyForm").hide();
    $("#IssueBookDetails").hide();
    $("#returnBookDetails").hide();
  });
  // Add user detail Section popup 
  $("#addUser").click(function () {
    $("#addBookDetail").hide();
    $("#addUserDetail").toggle();
    $("#getBookDetail").hide();
    $("#getUserDetail").hide();
    $("#CalPenaltyForm").hide();
    $("#IssueBookDetails").hide();
    $("#returnBookDetails").hide();
  });
  // get user detail Section popup 
  $("#getUser").click(function () {
    $("#addUserDetail").hide();
    $("#addBookDetail").hide();
    $("#getUserDetail").toggle();
    $("#getBookDetail").hide();
    $("#CalPenaltyForm").hide();
    $("#IssueBookDetails").hide();
    $("#returnBookDetails").hide();

  });
  // get book details pop up 
  $("#getBook").click(function () {
    $("#addUserDetail").hide();
    $("#addBookDetail").hide();
    $("#getUserDetail").hide();
    $("#getBookDetail").toggle();
    $("#CalPenaltyForm").hide();
    $("#IssueBookDetails").hide();
    $("#returnBookDetails").hide();
  });
  // get penalty pop up 
  $("#CalPenalty").click(function () {
    $("#addUserDetail").hide();
    $("#addBookDetail").hide();
    $("#getUserDetail").hide();
    $("#getBookDetail").hide();
    $("#CalPenaltyForm").toggle();
    $("#IssueBookDetails").hide();
    $("#returnBookDetails").hide();
  });
  // issue book details pop up 
  $("#IssueBook").click(function () {
    $("#addUserDetail").hide();
    $("#addBookDetail").hide();
    $("#getUserDetail").hide();
    $("#getBookDetail").hide();
    $("#CalPenaltyForm").hide();
    $("#IssueBookDetails").toggle();
    $("#returnBookDetails").hide();
  });
  // issue book details pop up 
  $("#returnBook").click(function () {
    $("#addUserDetail").hide();
    $("#addBookDetail").hide();
    $("#getUserDetail").hide();
    $("#getBookDetail").hide();
    $("#CalPenaltyForm").hide();
    $("#IssueBookDetails").hide();
    $("#returnBookDetails").toggle();
  });
  // Add book details 
  $("#addBookDone").click(function (e) {
    var book = new Object();
    book.bookName = $('#addBookName').val();
    book.Category = $('#addBookCategory').val();
    book.Price = parseFloat($('#addBookPrice').val());
    book.ShelfNumber = parseInt($('#addBookShelfNumber').val());
    book.IssuedStatus = $('#addBookStatus').val();
    console.log(book);
    e.preventDefault();
    $.ajax({
      url: 'https://localhost:5001/penalty/postBook',
      type: 'post',
      dataType: 'json',
      contentType: 'application/json',
      data: JSON.stringify(book),

      success: function (response) {
        console.log(response);
      },
      error: function (response) {
        console.log(response.responseText),
          alert(response.responseText);
      }
    });
  });
  // Add user details 
  $("#addUserDone").click(function (e) {
    var user = new Object();
    user.username = $('#addUserName').val();
    console.log(user);
    e.preventDefault();
    $.ajax({
      url: 'https://localhost:5001/penalty/postUser',
      type: 'post',
      dataType: 'json',
      contentType: 'application/json',
      data: JSON.stringify(user),

      success: function (response) {
        console.log(response);
      },
      error: function (response) {
        console.log(response.responseText),
          alert(response.responseText);
      }
    });
  });


  $("#editBookDone").click(function (e) {
    var book = new Object();
    book.bookName = $('#editBookName').val();
    book.Category = $('#editBookCategory').val();
    book.Price = parseFloat($('#editBookPrice').val());
    book.ShelfNumber = parseInt($('#editBookShelfNumber').val());
    book.IssuedStatus = $('#editBookStatus').val();
    console.log(book);
    e.preventDefault();
    $.ajax({
      url: 'https://localhost:5001/penalty/putBook/' + $("#editBookID").val(),
      type: 'put',
      dataType: 'json',
      contentType: 'application/json',
      data: JSON.stringify(book),

      success: function (response) {
        console.log(response);
      },
      error: function (response) {
        console.log(response.responseText),
          alert(response.responseText);
      }
    });
    $("#editBookDetail").hide();
  });
  $("#editUserDone").click(function (e) {
    var user = new Object();
    user.username = $('#editUserName').val();
    user.editUserID = $('#editUserID').val();

    console.log(user);
    e.preventDefault();
    $.ajax({
      url: 'https://localhost:5001/penalty/putUser/' + $("#editUserID").val(),
      type: 'put',
      dataType: 'json',
      contentType: 'application/json',
      data: JSON.stringify(user),

      success: function (response) {
        console.log(response);
      },
      error: function (response) {
        console.log(response.responseText),
          alert(response.responseText);
      }
    });
    $("#editUserDetail").hide();
  });

  //GET USER DETAIL
  $("#getUserDone").click(function (e) {
    $("#userDetailsID").show();
    $("#userDetailsTable").show();
    $("#usersDetailsID").hide();
    $("#booksDetailsID").hide();
    $("#getBookDetail").hide();
    $("#getUserDetail").show();
    href = 'https://localhost:5001/penalty/user/' + parseInt($('#getUserName').val());
    e.preventDefault();
    $.ajax({
      url: href,
      method: "get",
      dataType: "json",
      contentType: "application/json",
      async: true,
      success: function (data) {
        console.log(data)
        a = [];
        a.push(data)
        populateUserTable(a)
      },
      error: function (data) {
        alert('No User like that exist');
      }
    });
  });
  //get book details
  $("#getBookDone").click(function (e) {
    $("#booksDetailsID").show();
    $("#userDetailsID").hide();
    $("#usersDetailsID").hide();
    $("#getBookDetail").hide();
    $("#getUserDetail").hide();
    var str = $('#getBookName').val();
    href = "https://localhost:5001/penalty/book/" + str;
    e.preventDefault();
    $.ajax({
      url: href,
      method: "get",
      dataType: "json",
      contentType: "application/json",
      async: true,
      success: function (data) {
        a = [];
        a.push(data)
        console.log(data)
        populateBooksTable(a)
      },
      error: function (data) {
        alert('No Book like that exist');
      }
    });
  });
  //get book penlaty
  $("#CalPenaltyDone").click(function (e) {
    $("#booksDetailsID").hide();
    $("#userDetailsID").hide();
    $("#usersDetailsID").hide();
    $("#getBookDetail").hide();
    $("#getUserDetail").hide();
    $("#CalPenaltyForm").hide();
    var str = $('#bookPenalty').val();
    href = "https://localhost:5001/penalty/CalculatePenalty/" + str;
    e.preventDefault();
    $.ajax({
      url: href,
      method: "get",
      dataType: "json",
      contentType: "application/json",
      async: true,
      success: function (response) {
        console.log(response.responseText)
        alert(response.responseText)
      },
      error: function (response) {
        alert(response.responseText);
      }
    });
  });
  //issue book to user
  $("#issueBookDone").click(function (e) {
    $("#booksDetailsID").hide();
    $("#userDetailsID").hide();
    $("#usersDetailsID").hide();
    $("#getBookDetail").hide();
    $("#getUserDetail").hide();
    $("#IssueBookDetails").hide();
    var userID = $('#issueUserID').val();
    var book = new Object();
    var bookName = $('#issueBookName').val();
    href = 'https://localhost:5001/penalty/issueBook/' + parseInt(userID);
    e.preventDefault();
    $.ajax({
      url: href,
      type: 'put',
      dataType: 'json',
      contentType: 'application/json',
      data: JSON.stringify(bookName),

      success: function (response) {
        console.log(response);
      },
      error: function (response) {
        console.log(response.responseText),
          alert(response.responseText);
      }
    });
  });
  //return book from user
  $("#returnBookDone").click(function (e) {
    $("#booksDetailsID").hide();
    $("#userDetailsID").hide();
    $("#usersDetailsID").hide();
    $("#getBookDetail").hide();
    $("#getUserDetail").hide();
    $("#IssueBookDetails").hide();
    $("#returnBookDetails").hide();
    var userID = $('#returnUserID').val();
    var book = new Object();
    var bookName = $('#returnBookName').val();
    href = 'https://localhost:5001/penalty/userBooks/' + parseInt(userID);
    e.preventDefault();
    $.ajax({
      url: href,
      type: 'put',
      dataType: 'json',
      contentType: 'application/json',
      data: JSON.stringify(bookName),

      success: function (response) {
        console.log(response);
      },
      error: function (response) {
        console.log(response.responseText),
          alert(response.responseText);
      }
    });
  });
});




function populateBooksTable(data) {

  $("#bookDetailTable").dataTable({
    data: data,
    "paging": true,
    "lengthChange": false,
    "searching": true,
    "ordering": true,
    "info": true,
    "autoWidth": true,
    "bDestroy": true,
    columns: [
      { "data": "bookID" },
      { "data": "bookName" },
      { "data": "category" },
      { "data": "price" },
      { "data": "shelfNumber" },
      { "data": "issuedStatus" },
      { "data": "issuedTo" },
      { "data": "issuedDate" },
      {
        'data': 'bookID',

        'render': function (data) { return '<button type="button" id="editBookBtn" class="btn  btn-primary px-4" onclick="onUpdate(' + data + ')">Edit</button>' }

      }
      ,
      {
        'data': "bookID",
        'render': function (data) { return '<button type="button" id="deleteBookBtn" class="btn  btn-danger " onclick="deleteBook(' + data + ')">Delete</button>' }

      }
    ]
  })

}
function populateUsersTable(data) {
  $("#userDetailTable").dataTable({
    data: data,
    "paging": true,
    "lengthChange": false,
    "searching": true,
    "ordering": true,
    "info": true,
    "autoWidth": true,
    "bDestroy": true,
    columns: [
      { "data": "userID" },
      { "data": "username" },
      {
        'data': 'userID',

        'render': function (data) { return '<button type="button" id="editUserBtn" class="btn  btn-primary px-4" onclick="onUserUpdate(' + data + ')">Edit</button>' }

      }
      ,
      {
        'data': "userID",
        'render': function (data) { return '<button type="button" id="deleteUserBtn" class="btn  btn-danger " onclick="deleteUser(' + data + ')">Delete</button>' }

      }
    ]
  })
}
function populateUserTable(data) {
  $("#userDetailsTable").dataTable({
    data: data,
    "paging": true,
    "lengthChange": false,
    "searching": true,
    "ordering": true,
    "info": true,
    "autoWidth": true,
    "bDestroy": true,

    columns: [
      { "data": "item1" },
      { "data": "item2" },
      { "data": "item3" }
    ]
  })
}
function deleteBook(bookID) {

  var table = $("#bookDetailTable").DataTable();
  var data = table
    .rows()
    .data();
  var bookData;
  for (let i = 0; i < data.length; i++) {
    let temp = data[i]
    if (temp.bookID === bookID) {
      console.log(data[i])
      bookData = data[i]
    }
  }
  $.ajax({
    url: "https://localhost:5001/penalty/delBook/" + bookData.bookName,
    method: "delete",
    dataType: "json",
    contentType: "application/json",
    async: true,
    success: function (data) {

      console.log(data)

    },
    error: function (response) {
      console.log(response.responseText),
        alert(response.responseText);
    }
  });

}
function deleteUser(userID) {

  var table = $("#userDetailTable").DataTable();

  $.ajax({
    url: "https://localhost:5001/penalty/delUser/" + userID,
    method: "delete",
    dataType: "json",
    contentType: "application/json",
    async: true,
    success: function (data) {

      console.log(data)

    },
    error: function (response) {
      console.log(response.responseText),
        alert(response.responseText);
    }
  });

}
$("#userDetailTable").on('click', '#deleteUserBtn', function () {
  $(this).closest('tr').remove();
})

$("#bookDetailTable").on('click', '#deleteBookBtn', function () {
  $(this).closest('tr').remove();

})

function onUpdate(bookID) {
  $("#editBookDetail").show();
  var table = $("#bookDetailTable").DataTable();
  var data = table
    .rows()
    .data();
  var bookData;
  for (let i = 0; i < data.length; i++) {
    let temp = data[i]
    if (temp.bookID === bookID) {
      console.log(data[i])
      bookData = data[i]
    }
  }
  $("#editBookName").val(bookData.bookName)
  $("#editBookCategory").val(bookData.category)
  $('#editBookPrice').val(bookData.price)
  $("#editBookShelfNumber").val(bookData.shelfNumber)
  $("#editBookStatus").val(bookData.issuedStatus)
  $("#editBookID").val(bookData.bookID)

}
function onUserUpdate(userID) {
  $("#editUserDetail").show();
  var table = $("#userDetailTable").DataTable();
  var data = table
    .rows()
    .data();
  var userData;
  for (let i = 0; i < data.length; i++) {
    let temp = data[i]
    if (temp.userID === userID) {
      userData = data[i]
    }
  }
  $("#editUserName").val(userData.username)
  $("#editUserID").val(userData.userID)

}
