use SQL_Assignment1 
--Task0_Fill Books Table
insert into books(Bookname,Category,Price,ShelfNumber,IssuedStatus,IssuedTo,IssuedDate)
values
('Book1','Mystery',13.63,101,'Not Available',1,'2022-10-01'),
('Book2','Mystery',14.00,102,'Not Available',2,'2022-10-01'),
('Book3','Mystery',15.50,103,'Not Available',3,'2022-10-15'),
('Book4','Mystery',14.50,104,'Not Available',4,'2022-11-01'),
('Book5','Mystery',13.00,105,'Not Available',5,'2022-11-01'),
('Book6','Mystery',13.50,106,'Available',null,null),
('Book7','Mystery',12.50,107,'Available',null,null),
('Book8','Mystery',12.00,108,'Available',null,null),
('Book9','Mystery',16.00,109,'Available',null,null),
('Book10','Mystery',16.50,110,'Available',null,null),
('Book11','Mystery',17.00,111,'Available',null,null),
('Book12','Mystery',17.50,112,'Available',null,null),
('Book13','Mystery',18.00,113,'Available',null,null),
('Book14','Mystery',18.50,114,'Available',null,null),
('Book15','Mystery',19.00,115,'Available',null,null),
('Book16','Mystery',19.50,116,'Not Available',1,'2022-11-01'),
('Book17','Mystery',20.00,117,'Not Available',2,'2022-11-11'),
('Book18','Mystery',20.50,118,'Not Available',3,'2022-10-01'),
('Book19','Mystery',11.50,119,'Not Available',4,'2022-10-10'),
('Book20','Mystery',11,120,'Not Available',5,'2022-10-30');
select * from books
------------------------------
--Task0_Fill Users Table
insert into users(Username)
values
('User1'),
('User2'),
('User3'),
('User4'),
('User5'),
('User6'),
('User7'),
('User8'),
('User9'),
('User10');
select * from users
-------------------------------------
