use SQL_Assignment1 
--Task0_Create Books Table
create table books(
BookID int not null primary key identity(1,1),
Bookname varchar(255),
Category varchar(255),
Price float(5),
ShelfNumber int,
IssuedStatus varchar(255) default 'Available',
IssuedTo int default null,
IssuedDate date default null,
ReturnDate date default null
);
select * from books
--------------------------

--Task0_Create User Table
Go
create table users(
	UserID int not null primary key identity(1,1),
	Username varchar(255),
);
select * from users
---------------------------
