use SQL_Assignment1 
-------------------------Task0_Get_ALL_BOOKS
Go
CREATE PROCEDURE sp_GetBooks
AS
BEGIN
	select * from books 
END
Go
exec sp_GetBooks
-------------------------Task0_Get_ALL_Users
Go
CREATE PROCEDURE sp_GetUsers
AS
BEGIN
	select * from users
END
GO
exec sp_GetUsers
--------------------------Task1 Insert book
Go
CREATE PROCEDURE sp_InsertBook
       @Bookname varchar(255),
       @Category varchar(255),
       @Price float(5),
       @ShelfNumber int,
	   @IssuedStatus varchar(255)
AS
BEGIN
       INSERT INTO books
              (Bookname, Category, Price, ShelfNumber,IssuedStatus)
       VALUES
              (@Bookname, @Category, @Price, @ShelfNumber,@IssuedStatus)
END
Go
exec sp_InsertBook 'Book19','Drama',14.5,110,'Available'
exec sp_GetBooks
----------------------------Task2 Insert user
Go
CREATE PROCEDURE sp_InsertUser
       @UserName varchar(255)
AS
BEGIN
       INSERT INTO users(UserName) VALUES(@UserName)
END
Go
-----------------------------Task3 get a book's details
Go
CREATE PROCEDURE sp_GetBook
       @Bookname varchar(255)
AS
BEGIN
	select * from books where Bookname= @Bookname
END
Go

------------------------------Task4 get a user's details
Go
CREATE PROCEDURE sp_GetUser
       @UserId int
AS
BEGIN
	select users.UserID, users.Username, isnull(books.Bookname,'No Book issued') as BookName from users
left join books on books.IssuedTo=users.UserID
where users.UserID=@UserId

END
Go

-------------------------------Task5 update a book
Go
CREATE PROCEDURE sp_UpdateBook
	@BookId int,
	@Bookname varchar(255),
	@Category varchar(255),
	@Price float(5),
	@ShelfNumber int,
	@IssuedStatus varchar(255)
AS
BEGIN
	update books set 
		BookName=@BookName,
		Category=@Category,
		Price=@Price,
		ShelfNumber=@ShelfNumber,
		IssuedStatus=@IssuedStatus
		where BookId=@BookId;
END
GO

-------------------------------Task6 update a user
Go
CREATE PROCEDURE sp_UpdateUser
	@UserId int,
	@Username varchar(255)
AS
BEGIN
	update users set 
		Username=@Username
		where UserId=@UserId;
END
Go

----------------------------------Task7 issue book to user
Go
CREATE PROCEDURE sp_IssueBook
	@UserId int,
	@Bookname varchar(255)
AS
BEGIN
	IF EXISTS (select * from users where UserID = @UserID)
	begin
		IF EXISTS (select * from books where Bookname = @Bookname)
		begin

			Declare @varUser int
			select @varUser=IssuedTo from books where Bookname=@Bookname
			if (@varUser is null)
			begin 
			update books set 
			IssuedTo=@UserId,
			IssuedDate= cast(getdate() as date),
			IssuedStatus='Not Available' 
			where BookName=@BookName;
			select -4 as Issued
			return
			end
			else
			begin select -3 as Issued end
		end
		else
		begin select -2 as Issued end
	end
	else
		begin
			select -1 as Issued
		end
END
Go
exec sp_IssueBook 4,Book13
select * from books
drop procedure sp_IssueBook
-------------------------------Task8 remove a book from table
GO
CREATE PROCEDURE sp_RemoveBook
	@Bookname varchar(255)
AS
BEGIN
	delete from books where Bookname=@Bookname	
END
Go
exec sp_RemoveBook 'Book19'
exec sp_GetBooks
------------------------------Task9 Remove a user form table check for issued books before
Go
CREATE PROCEDURE sp_RemoveUser
	@UserId int
AS
BEGIN
	Declare @varUser int
	declare @r varchar(100)
	select @varUser=IssuedTo from books where IssuedTo=@UserId
	if (@varUser is null)
	begin
		delete from users where UserID=@UserId
	end
END
Go

------------------------------------Task10 Get all books issued by a user
Go
CREATE PROCEDURE sp_ReturnBook
	@UserID int,
	@BookName varchar(255)
AS
BEGIN
IF EXISTS (select * from users where UserID = @UserID)
	begin
		IF EXISTS (select * from books where Bookname = @Bookname)
		begin

			Declare @varUser int
			select @varUser=IssuedTo from books where Bookname=@Bookname
			if (@varUser =@UserID)
			begin 
			update books set 
			IssuedTo=null,
			IssuedDate= null,
			IssuedStatus='Available' ,
			ReturnDate=cast(getdate() as date)
			where BookName=@BookName;
			select -4 as Returned
			return
			end
			else
			begin select -3 as Returned end
		end
		else
		begin select -2 as Returned end
	end
	else
		begin
			select -1 as Returned
		end
END
Go
exec sp_ReturnBook 4,Book13
exec sp_GetBooks

------------------------------------------